var searchData=
[
  ['writepgmimage_51',['WritePGMImage',['../imageIO_8h.html#afa4e9ec3a7e42244a7b3906c90e934e4',1,'WritePGMImage(const char *path, const unsigned char *datos, const int rows, const int cols):&#160;imageIO.cpp'],['../imageIO_8cpp.html#aaa77c6f72e62cb8273775dcfe7a49f1f',1,'WritePGMImage(const char *nombre, const unsigned char *datos, const int rows, const int cols):&#160;imageIO.cpp']]]
];
